#ifndef PRINT_H
#define PRINT_H

#include<string>
#include<queue> 
#include<iostream>
using namespace std;
class print
{
public :
	void PrintStringQueue (queue<string> result);
};

#endif 
