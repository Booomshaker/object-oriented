#ifndef CALCULATION_H
#define CALCULATION_H

#include<string>
#include<queue>
#include<iostream>
#include<sstream>
#include<stack>
using namespace std;
class calculation
{
	public:
		stack<double> ToStack(queue<string> something);
};

#endif
